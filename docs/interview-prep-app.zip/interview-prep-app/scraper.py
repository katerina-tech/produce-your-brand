"""
scraper.py
Fetches a job posting URL and extracts readable text, plus a smart
validation check comparing the entered company name against the URL's domain.
"""

import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse

MAX_CHARS = 8000
REQUEST_TIMEOUT = 15
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0 Safari/537.36"
)


def fetch_job_description_from_url(url: str):
    """
    Returns (text, error). Exactly one of them will be truthy.
    """
    if not url or not url.strip():
        return None, "Please paste a job posting URL first."

    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        response = requests.get(
            url, headers={"User-Agent": USER_AGENT}, timeout=REQUEST_TIMEOUT
        )
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        return None, f"Couldn't fetch that page ({e}). Try pasting the description manually."

    soup = BeautifulSoup(response.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "noscript", "svg", "form"]):
        tag.decompose()

    text = soup.get_text(separator="\n")
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    cleaned = "\n".join(lines)

    if len(cleaned) < 200:
        return None, (
            "Fetched the page, but couldn't find enough readable text on it. "
            "Some job sites block automated access — try pasting the description manually."
        )

    if len(cleaned) > MAX_CHARS:
        cleaned = cleaned[:MAX_CHARS]

    return cleaned, None


def guess_company_from_url(url: str) -> str:
    """Best-effort guess of a company name from a URL's domain (e.g. 'netlight.com' -> 'Netlight')."""
    if not url or not url.strip():
        return ""
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    try:
        netloc = urlparse(url).netloc.lower()
        netloc = netloc.replace("www.", "")
        for prefix in ("jobs.", "careers.", "boards.", "apply."):
            if netloc.startswith(prefix):
                netloc = netloc[len(prefix):]
        domain_root = netloc.split(".")[0]
        return domain_root.replace("-", " ").title()
    except Exception:
        return ""


def check_company_mismatch(entered_company: str, job_url: str) -> str | None:
    """
    Returns a warning string if the entered company doesn't seem to match the
    job URL's domain, or None if they match (or there's nothing to compare).
    This is intentionally a soft, non-blocking check.
    """
    if not entered_company or not entered_company.strip():
        return None
    if not job_url or not job_url.strip():
        return None

    guessed = guess_company_from_url(job_url)
    if not guessed:
        return None

    normalize = lambda s: "".join(ch for ch in s.lower() if ch.isalnum())
    guessed_norm = normalize(guessed)
    entered_norm = normalize(entered_company)

    if not guessed_norm or not entered_norm:
        return None

    if guessed_norm in entered_norm or entered_norm in guessed_norm:
        return None

    return (
        f"The company name doesn't seem to match the provided job posting URL "
        f"(entered: \"{entered_company}\", URL suggests: \"{guessed}\"). "
        f"Double-check before generating, or continue if this is expected "
        f"(e.g. a careers page hosted on a different domain)."
    )
