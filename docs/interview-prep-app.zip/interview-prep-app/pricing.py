"""
pricing.py
Fetches live per-model pricing from the OpenRouter /models endpoint and
turns a usage dict (prompt_tokens/completion_tokens) into a USD cost.
"""

import requests

MODELS_ENDPOINT = "https://openrouter.ai/api/v1/models"

_pricing_cache: dict = {}


def fetch_all_pricing(force_refresh: bool = False) -> dict:
    """
    Returns {model_id: {"prompt": price_per_token_usd, "completion": price_per_token_usd}}.
    Fails silently (returns whatever is cached, possibly empty) so a pricing
    outage never breaks report generation.
    """
    global _pricing_cache
    if _pricing_cache and not force_refresh:
        return _pricing_cache

    try:
        response = requests.get(MODELS_ENDPOINT, timeout=15)
        response.raise_for_status()
        data = response.json()
        fresh_cache = {}
        for model in data.get("data", []):
            pricing = model.get("pricing", {})
            try:
                fresh_cache[model["id"]] = {
                    "prompt": float(pricing.get("prompt", 0) or 0),
                    "completion": float(pricing.get("completion", 0) or 0),
                }
            except (TypeError, ValueError):
                continue
        if fresh_cache:
            _pricing_cache = fresh_cache
    except requests.exceptions.RequestException:
        pass

    return _pricing_cache


def calculate_cost(model_id: str, usage: dict) -> dict | None:
    """
    Given a model id and a usage dict (prompt_tokens/completion_tokens),
    returns a breakdown in USD, or None if pricing isn't available.
    """
    if not usage:
        return None

    pricing = fetch_all_pricing()
    rates = pricing.get(model_id)
    if not rates:
        return None

    prompt_tokens = usage.get("prompt_tokens", 0)
    completion_tokens = usage.get("completion_tokens", 0)

    prompt_cost = prompt_tokens * rates["prompt"]
    completion_cost = completion_tokens * rates["completion"]

    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "prompt_cost": prompt_cost,
        "completion_cost": completion_cost,
        "total_cost": prompt_cost + completion_cost,
    }


def format_cost(cost: float) -> str:
    """Formats a USD float sensibly whether it's fractions of a cent or dollars."""
    if cost < 0.01:
        return f"${cost:.5f}"
    return f"${cost:.4f}"
