"""
strategies.py
Registry of prompt-engineering strategies. Each strategy defines its own
system prompt and any extra user-prompt instructions, while all strategies
share the same JSON output schema (prompts.JSON_SCHEMA_INSTRUCTIONS) so
every report renders identically in the UI regardless of which strategy
produced it.

TO ADD A NEW STRATEGY: add one entry to STRATEGIES below. Nothing else in
the app needs to change — app.py reads the registry dynamically.
"""

from prompts import JSON_SCHEMA_INSTRUCTIONS

FEW_SHOT_EXAMPLE = """
Here is a worked example showing the structure and level of specificity expected
(shortened for brevity — your real answer must be the FULL schema below):

Example job: "Backend Developer at Acme Corp, building scalable APIs with PostgreSQL and Go."
Example key_skills entry: {"skill": "PostgreSQL", "importance": "High", "why_it_matters": "Acme's APIs are data-heavy; query optimization is a core daily task.", "category": "Technical"}
Example technical question: "Walk me through how you'd design an indexing strategy for a table with 100M+ rows that's queried by date range."

Follow this same level of specificity — tied to the actual company, tools, and
responsibilities in the job description — for every section below.
"""


def _base_user_prompt(company, job_title, job_description, resume_section, language_directive, extra_instructions=""):
    return f"""Analyze the following job posting and generate a complete interview preparation report.

Company: {company or "Not specified"}
Job Title: {job_title or "Not specified"}

Job Description:
\"\"\"
{job_description}
\"\"\"
{resume_section}
{extra_instructions}
{language_directive}

{JSON_SCHEMA_INSTRUCTIONS}
"""


STRATEGIES = {
    "zero_shot": {
        "label": "Zero-shot",
        "description": "Direct instructions, no examples. Fastest and cheapest; good baseline.",
        "system_prompt": (
            "You are a helpful career assistant. Analyze the job posting below and "
            "generate an interview preparation report. Respond only with the requested JSON."
        ),
        "extra_instructions": "",
    },
    "few_shot": {
        "label": "Few-shot",
        "description": "Includes a worked example to guide structure, specificity, and tone.",
        "system_prompt": (
            "You are a career coach who writes structured interview preparation reports. "
            "Study the example provided, then match its style and level of detail for the "
            "real job posting. Respond only with the requested JSON."
        ),
        "extra_instructions": FEW_SHOT_EXAMPLE,
    },
    "role_expert": {
        "label": "Role-based Expert",
        "description": "Persona prompting — a senior recruiter persona shapes tone, judgment, and specificity.",
        "system_prompt": (
            "You are an experienced Senior Technical Recruiter and Interview Coach with "
            "expertise in hiring software engineers, AI engineers, data engineers, analysts, "
            "consultants, and product professionals. Your goal is to analyze job descriptions "
            "and generate practical interview preparation materials. Your responses should be "
            "structured, actionable, specific, and concise. Avoid generic advice. Tailor every "
            "recommendation to the provided company, role, and job description. Respond only "
            "with the requested JSON."
        ),
        "extra_instructions": "",
    },
    "resume_match": {
        "label": "Resume Match",
        "description": "Weighs the candidate's resume heavily. Best when a resume is provided; degrades gracefully otherwise.",
        "system_prompt": (
            "You are a career coach specializing in resume-to-job matching. Your primary focus "
            "is comparing the candidate's actual background (from resume excerpts, if provided) "
            "against this specific job's requirements, and tailoring every section — especially "
            "topics_to_study and confidence_score — around the real gaps and strengths you find. "
            "If no resume was provided, say so clearly in resume_match.personalized_note and keep "
            "other sections generic. Respond only with the requested JSON."
        ),
        "extra_instructions": "",
    },
    "structured_expert": {
        "label": "Structured Expert",
        "description": "Reasons privately about the role's demands first, then commits to a tightly organized report.",
        "system_prompt": (
            "You are a senior interview coach who thinks methodically before writing. Internally, "
            "first identify the role's seniority, core technical demands, and likely evaluation "
            "criteria — do not show this reasoning in your output. Then produce a maximally "
            "well-organized, unambiguous interview preparation report based on that analysis. "
            "Respond only with the requested JSON, with no visible reasoning."
        ),
        "extra_instructions": "",
    },
}

DEFAULT_STRATEGY_ID = "role_expert"


def get_strategy(strategy_id: str) -> dict:
    return STRATEGIES.get(strategy_id, STRATEGIES[DEFAULT_STRATEGY_ID])


def build_strategy_prompts(
    strategy_id: str,
    company: str,
    job_title: str,
    job_description: str,
    resume_section: str,
    language_directive: str,
) -> tuple[str, str]:
    """Returns (system_prompt, user_prompt) for the given strategy id."""
    strategy = get_strategy(strategy_id)
    user_prompt = _base_user_prompt(
        company, job_title, job_description, resume_section, language_directive,
        extra_instructions=strategy["extra_instructions"],
    )
    return strategy["system_prompt"], user_prompt
