"""
resume_reader.py
Extracts text from an uploaded resume file — PDF or Excel (.xlsx).

For PDFs: tries pypdf first (fast), falls back to pdfplumber (handles
font/encoding edge cases pypdf sometimes misses), and validates the file
actually starts with a real PDF signature first — so a mismatched or
corrupt file gets an accurate error instead of a misleading "scanned
image" message.
"""

from io import BytesIO

from pypdf import PdfReader

PDF_SIGNATURE = b"%PDF"


def _extract_with_pypdf(file_bytes: bytes) -> str:
    reader = PdfReader(BytesIO(file_bytes))
    pages_text = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages_text).strip()


def _extract_with_pdfplumber(file_bytes: bytes) -> str:
    import pdfplumber  # imported lazily — only needed if pypdf comes up empty

    text_parts = []
    with pdfplumber.open(BytesIO(file_bytes)) as pdf:
        for page in pdf.pages:
            text_parts.append(page.extract_text() or "")
    return "\n".join(text_parts).strip()


def extract_text_from_pdf(uploaded_file):
    """
    uploaded_file: a Streamlit UploadedFile object.
    Returns (text, error). Exactly one of them will be truthy.
    """
    try:
        file_bytes = uploaded_file.read()
    except Exception as e:
        return None, f"Couldn't read that file: {e}"

    if not file_bytes.startswith(PDF_SIGNATURE):
        return None, (
            "This file doesn't look like a valid PDF (it's missing the PDF file "
            "signature). If it was exported from Word, Excel, or Google Docs, "
            "make sure it was actually saved/exported as PDF rather than just "
            "renamed. You can also paste your resume text directly below."
        )

    full_text = ""
    try:
        full_text = _extract_with_pypdf(file_bytes)
    except Exception:
        full_text = ""

    if not full_text:
        try:
            full_text = _extract_with_pdfplumber(file_bytes)
        except Exception:
            full_text = ""

    if not full_text:
        return None, (
            "Couldn't extract any text from that PDF. It might be a scanned "
            "image, or it uses a font/encoding neither of our readers can parse. "
            "Try pasting your resume text instead, or re-export the PDF as "
            "'searchable text' from the original document."
        )

    return full_text, None


def extract_text_from_xlsx(uploaded_file):
    """
    uploaded_file: a Streamlit UploadedFile object (.xlsx).
    Returns (text, error). Exactly one of them will be truthy.
    """
    try:
        import openpyxl
        workbook = openpyxl.load_workbook(BytesIO(uploaded_file.read()), data_only=True)
    except Exception as e:
        return None, f"Couldn't read that Excel file: {e}"

    lines = []
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows(values_only=True):
            cells = [str(cell) for cell in row if cell is not None and str(cell).strip()]
            if cells:
                lines.append(" | ".join(cells))

    full_text = "\n".join(lines).strip()
    if not full_text:
        return None, "Couldn't find any text in that spreadsheet."

    return full_text, None


def extract_resume_text(uploaded_file):
    """Dispatches to the right extractor based on file extension."""
    filename = (uploaded_file.name or "").lower()
    if filename.endswith(".xlsx"):
        return extract_text_from_xlsx(uploaded_file)
    return extract_text_from_pdf(uploaded_file)
