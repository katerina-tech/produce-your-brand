"""
prompts.py
Shared JSON schema and prompt-building helpers used by every strategy in
strategies.py. The schema is organized around the 5 user-facing sections:
company_analysis, job_analysis, resume_match, interview_prep_plan
(mock interview itself is a live feature, not part of this JSON).
"""

JSON_SCHEMA_INSTRUCTIONS = """
Return a single valid JSON object with EXACTLY this structure and these keys:

{
  "company_analysis": {
    "overview": "2-4 sentences on what the company does, its focus, and what it generally values in candidates.",
    "culture_notes": "1-2 sentences on work style/culture, inferred from the job description if possible, otherwise a reasonable general note."
  },
  "job_analysis": {
    "seniority": "one short label, e.g. 'Mid-level' or 'Senior'",
    "role_summary": "2-3 sentences on the role's core responsibilities and expected candidate profile.",
    "key_skills": [
      {"skill": "string", "importance": "High" | "Medium" | "Low", "why_it_matters": "string", "category": "Technical" | "Soft"}
    ],
    "topics_to_study": [
      {"topic": "string", "priority_stars": 1-5 integer, "reason": "one sentence"}
    ],
    "confidence_score": {
      "percentage": integer between 0 and 100,
      "covered": ["what a well-prepared candidate already has covered by studying the above"],
      "improve": ["what still needs improvement or deeper focus"]
    }
  },
  "resume_match": {
    "matched_skills": ["skills or experience from the candidate's resume excerpts that directly match this job's requirements — empty list if no resume excerpts were provided"],
    "gaps": ["requirements from the job description that the resume excerpts do NOT show evidence of — empty list if no resume excerpts were provided"],
    "personalized_note": "one short paragraph of personalized advice based on the resume excerpts, or 'No resume was provided, so this section is generic. Add your resume for a personalized match.' if none were given"
  },
  "interview_prep_plan": {
    "technical_questions": ["exactly 10 tailored technical questions as strings"],
    "behavioural_questions": ["exactly 5 STAR-style behavioural questions as strings"],
    "questions_to_ask": ["exactly 8 thoughtful questions to ask the interviewer"],
    "study_plan": [
      {"day": "Day 1", "tasks": ["task 1", "task 2"]}
    ]
  }
}

Rules:
- key_skills should include both technical and soft skills, sorted with highest importance first.
- topics_to_study should be sorted with the highest priority_stars first.
- study_plan should have 3 to 5 days, realistic and specific to this role.
- Do not include any text outside the JSON object. No ```json fences.
"""

LANGUAGE_NAMES = {
    "en": "English",
    "de": "German",
    "ru": "Russian",
}


def language_instruction(language_code: str) -> str:
    """Returns an instruction snippet to insert into the user prompt, or '' for English."""
    if language_code == "en" or language_code not in LANGUAGE_NAMES:
        return ""
    name = LANGUAGE_NAMES[language_code]
    return (
        f"\nWrite ALL text values in the JSON (summaries, questions, notes, reasons, etc.) "
        f"in {name}. Keep the JSON keys themselves in English exactly as specified below.\n"
    )


def build_resume_section(resume_chunks: list | None) -> str:
    """Builds the resume-context block inserted into the user prompt."""
    if resume_chunks:
        return (
            "\n\nThe candidate also provided their resume. Below are the resume "
            "excerpts most relevant to this job (retrieved by semantic similarity "
            "to the job description). Use them to personalize the resume_match "
            "section and the confidence_score:\n\"\"\"\n"
            + "\n---\n".join(resume_chunks)
            + "\n\"\"\""
        )
    return (
        "\n\nNo resume was provided by the candidate. Leave matched_skills and "
        "gaps as empty lists and set personalized_note accordingly."
    )


EXAMPLE_JOB_DESCRIPTION = {
    "company": "Google",
    "job_title": "AI Engineer",
    "job_description": (
        "We are looking for an AI Engineer to join our Cloud AI team. "
        "You will design, build, and deploy machine learning systems at scale, "
        "collaborate with research scientists to productionize models, and "
        "optimize inference pipelines for latency and cost. "
        "Requirements: strong Python skills, experience with PyTorch or "
        "TensorFlow, solid understanding of SQL and data pipelines, "
        "familiarity with distributed systems and cloud infrastructure "
        "(GCP preferred), and experience with LLM-based applications is a plus. "
        "You will work closely with product managers to translate business "
        "requirements into technical solutions, and you will be expected to "
        "mentor junior engineers and communicate complex technical concepts "
        "to non-technical stakeholders. 3+ years of experience required."
    ),
}
