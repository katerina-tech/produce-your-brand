"""
api_client.py
Handles all communication with the AI service: chat completions
(with token usage returned for cost tracking) and embeddings (for the
resume-matching RAG feature).
"""

import json
import os
import re

import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("OPENROUTER_API_KEY")
CHAT_URL = "https://openrouter.ai/api/v1/chat/completions"
EMBEDDINGS_URL = "https://openrouter.ai/api/v1/embeddings"
DEFAULT_MODEL = "openai/gpt-5-mini"
DEFAULT_EMBEDDING_MODEL = "openai/text-embedding-3-small"


def _require_key():
    if not API_KEY:
        raise ValueError(
            "OPENROUTER_API_KEY not found. Make sure you created a .env file "
            "with your key (see .env.example)."
        )


def _strip_code_fences(text: str) -> str:
    """Remove ```json ... ``` fences if the model adds them despite instructions."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?", "", text)
    text = re.sub(r"```$", "", text)
    return text.strip()


def call_openrouter(
    messages: list,
    model: str = DEFAULT_MODEL,
    temperature: float = 0.5,
    max_tokens: int = 4000,
    top_p: float = 1.0,
) -> tuple[str, dict]:
    """
    Sends a chat completion request. Returns (content_string, usage_dict)
    where usage_dict has prompt_tokens / completion_tokens / total_tokens.
    """
    _require_key()

    try:
        response = requests.post(
            url=CHAT_URL,
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "top_p": top_p,
            },
            timeout=60,
        )
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Network error while contacting the AI service: {e}")

    if response.status_code != 200:
        raise RuntimeError(
            f"AI service error ({response.status_code}): {response.text[:500]}"
        )

    data = response.json()

    try:
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise RuntimeError(f"Unexpected API response shape: {data}")

    usage = data.get("usage", {}) or {}
    return content, usage


def get_structured_report(
    system_prompt: str,
    user_prompt: str,
    model: str = DEFAULT_MODEL,
    temperature: float = 0.5,
    max_tokens: int = 6000,
    top_p: float = 1.0,
) -> tuple[dict, dict]:
    """Calls the model and parses its response into (report_dict, usage_dict)."""
    raw, usage = call_openrouter(
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
    )

    cleaned = _strip_code_fences(raw)

    try:
        report = json.loads(cleaned)
    except json.JSONDecodeError as e:
        looks_truncated = "Unterminated string" in str(e) or len(cleaned) >= max_tokens * 3
        if looks_truncated:
            raise RuntimeError(
                "The AI's response was cut off before it finished (ran out of tokens). "
                "Try increasing max_tokens, or click Generate again. "
                f"(Parser error: {e})"
            )
        raise RuntimeError(
            "The AI response could not be parsed as JSON. This can happen "
            "occasionally — try clicking Generate again. "
            f"(Parser error: {e})"
        )

    return report, usage


def get_embeddings(texts: list, model: str = DEFAULT_EMBEDDING_MODEL) -> list:
    """Embeds a list of strings and returns a list of vectors (same order as input)."""
    _require_key()

    try:
        response = requests.post(
            url=EMBEDDINGS_URL,
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json",
            },
            json={"model": model, "input": texts},
            timeout=60,
        )
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Network error while contacting the embeddings service: {e}")

    if response.status_code != 200:
        raise RuntimeError(
            f"Embeddings service error ({response.status_code}): {response.text[:500]}"
        )

    data = response.json()

    if "error" in data:
        raise RuntimeError(
            f"Embeddings service error: {data['error'].get('message', data['error'])}"
        )

    try:
        return [item["embedding"] for item in data["data"]]
    except (KeyError, IndexError):
        raise RuntimeError(f"Unexpected embeddings response shape: {data}")
