"""
rag.py
A lightweight Retrieval-Augmented Generation step: the user's resume is
chunked and embedded, then compared against the job description so only
the most relevant resume snippets are injected into the LLM prompt.
"""

import math

from api_client import get_embeddings

MAX_CHUNK_CHARS = 350


def chunk_text(text: str, max_chars: int = MAX_CHUNK_CHARS) -> list:
    """Groups a resume's paragraphs/lines into chunks of roughly max_chars each."""
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    chunks, current = [], ""

    for line in lines:
        candidate = f"{current} {line}".strip()
        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                chunks.append(current)
            current = line

    if current:
        chunks.append(current)

    return chunks


def cosine_similarity(a: list, b: list) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def get_relevant_resume_chunks(resume_text: str, job_description: str, top_k: int = 5) -> list:
    """
    Retrieval step: embeds every resume chunk plus the job description,
    ranks chunks by cosine similarity to the job description, and returns
    the top_k most relevant ones. Returns [] if there's no resume text.
    """
    if not resume_text or not resume_text.strip():
        return []

    chunks = chunk_text(resume_text)
    if not chunks:
        return []

    all_embeddings = get_embeddings(chunks + [job_description])
    chunk_embeddings = all_embeddings[:-1]
    job_embedding = all_embeddings[-1]

    scored_chunks = [
        (cosine_similarity(chunk_embedding, job_embedding), chunk)
        for chunk_embedding, chunk in zip(chunk_embeddings, chunks)
    ]
    scored_chunks.sort(key=lambda pair: pair[0], reverse=True)

    return [chunk for _, chunk in scored_chunks[:top_k]]
