"""
app.py
AI Interview Coach — main Streamlit application.

Layout: main content (job input + report) on the left, a persistent
"Model Settings" panel on the right for anything technical (model,
temperature, max tokens, mock interview length, prompt strategy,
comparison mode, technical error details).
"""

import time

import streamlit as st

from api_client import get_structured_report, DEFAULT_MODEL
from guardrails import is_career_related
from interview_coach import evaluate_answer, build_mock_question_list
from prompts import build_resume_section, language_instruction, EXAMPLE_JOB_DESCRIPTION
from pricing import calculate_cost, format_cost
from rag import get_relevant_resume_chunks
from resume_reader import extract_resume_text
from scraper import fetch_job_description_from_url, check_company_mismatch
from strategies import STRATEGIES, DEFAULT_STRATEGY_ID, build_strategy_prompts
from utils import (
    is_safe_input,
    has_sufficient_job_content,
    report_to_markdown,
    report_to_pdf_bytes,
    score_report_quality,
)

st.set_page_config(
    page_title="AI Interview Coach",
    page_icon="🎯",
    layout="wide",
)

LANGUAGE_OPTIONS = {"English": "en", "German": "de", "Russian": "ru"}

# ---------- Custom styling ----------
st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', -apple-system, sans-serif;
    }
    .stButton>button {
        border-radius: 4px;
        font-weight: 600;
        border: 1px solid #0F172A;
    }
    .stButton>button[kind="primary"] {
        background-color: #0F172A;
        border: 1px solid #0F172A;
    }
    .app-header {
        border-bottom: 3px solid #0F172A;
        padding-bottom: 20px;
        margin-bottom: 28px;
    }
    .app-eyebrow {
        text-transform: uppercase;
        letter-spacing: 2px;
        font-size: 12px;
        color: #6B7280;
        font-weight: 600;
        margin: 0 0 8px 0;
    }
    .app-title {
        font-size: 36px;
        font-weight: 700;
        color: #0F172A;
        margin: 0;
        letter-spacing: -0.5px;
    }
    .app-subtitle {
        font-size: 16px;
        color: #4B5563;
        margin-top: 12px;
        max-width: 680px;
        line-height: 1.5;
    }
    .usage-strip {
        font-size: 13px;
        color: #6B7280;
        margin: 4px 0 20px 0;
    }
    .skill-row {
        border-left: 3px solid #0F172A;
        padding: 10px 16px;
        margin-bottom: 10px;
        background: #F9FAFB;
    }
    .skill-row-top {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        gap: 12px;
    }
    .skill-name { color: #0F172A; font-weight: 600; }
    .skill-meta {
        font-size: 11px; text-transform: uppercase; letter-spacing: 1px;
        color: #6B7280; font-weight: 600; white-space: nowrap;
    }
    .skill-why { font-size: 13px; color: #4B5563; margin-top: 4px; }
    </style>
    """,
    unsafe_allow_html=True,
)

IMPORTANCE_BORDER = {"High": "#0F172A", "Medium": "#475569", "Low": "#94A3B8"}


def render_skill_badges(skills: list):
    for s in skills:
        border = IMPORTANCE_BORDER.get(s.get("importance", ""), "#94A3B8")
        st.markdown(
            f"""
            <div class="skill-row" style="border-left-color:{border};">
                <div class="skill-row-top">
                    <span class="skill-name">{s.get('skill', '')}</span>
                    <span class="skill-meta">{s.get('importance', '')} · {s.get('category', '')}</span>
                </div>
                <div class="skill-why">{s.get('why_it_matters', '')}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


FRIENDLY_ERROR_MESSAGE = (
    "Something went wrong while preparing your report. Please try again — "
    "if it keeps happening, check the Model Settings panel for details."
)

# ---------- Session state ----------
defaults = {
    "report": None,
    "company": "",
    "job_title": "",
    "job_description": "",
    "job_url": "",
    "resume_text": "",
    "usage": None,
    "cost": None,
    "session_total_cost": 0.0,
    "model_used": DEFAULT_MODEL,
    "last_resume_filename": None,
    "language": "en",
    "strategy": DEFAULT_STRATEGY_ID,
    "compare_mode": False,
    "compare_strategy_ids": list(STRATEGIES.keys()),
    "compare_results": [],
    "mock_active": False,
    "mock_questions": [],
    "mock_index": 0,
    "mock_transcript": [],
    "last_error": None,
}
for key, value in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = value


def load_example():
    st.session_state.company = EXAMPLE_JOB_DESCRIPTION["company"]
    st.session_state.job_title = EXAMPLE_JOB_DESCRIPTION["job_title"]
    st.session_state.job_description = EXAMPLE_JOB_DESCRIPTION["job_description"]


def clear_inputs():
    st.session_state.company = ""
    st.session_state.job_title = ""
    st.session_state.job_description = ""
    st.session_state.job_url = ""
    st.session_state.resume_text = ""
    st.session_state.report = None
    st.session_state.usage = None
    st.session_state.cost = None
    st.session_state.last_resume_filename = None
    st.session_state.compare_results = []
    st.session_state.mock_active = False
    st.session_state.mock_questions = []
    st.session_state.mock_index = 0
    st.session_state.mock_transcript = []
    st.session_state.last_error = None


# ---------- Header (full width) ----------
st.markdown(
    """
    <div class="app-header">
        <p class="app-eyebrow">Your Interview Coach</p>
        <h1 class="app-title">AI Interview Coach</h1>
        <p class="app-subtitle">
            Tell me about the job you're applying for, and I'll help you get ready —
            company insight, what to study, how your resume stacks up, and a practice
            interview when you're ready.
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)

# ---------- Page layout: main content (left) + settings panel (right) ----------
main_col, settings_col = st.columns([3, 1], gap="large")

# ---------- Settings panel (right side) ----------
with settings_col:
    with st.container(border=True):
        st.markdown("#### ⚙️ Model Settings")
        model = st.selectbox(
            "Model",
            ["openai/gpt-5-mini", "openai/gpt-5-nano", "openai/gpt-5"],
            index=0,
            help="gpt-5-mini is the recommended default. gpt-5-nano is cheaper, gpt-5 is higher-capability.",
        )
        temperature = st.slider(
            "Temperature", 0.0, 1.0, 0.5, 0.05,
            help="Lower = more consistent/predictable output. Higher = more varied/creative.",
        )
        max_tokens = st.slider(
            "Max tokens",
            min_value=1000,
            max_value=10000,
            value=6000,
            step=500,
            help="Limits how long the AI's response can be. Too low can cut off a long report mid-way.",
        )
        mock_question_limit = st.slider(
            "Mock interview questions",
            min_value=1,
            max_value=20,
            value=10,
            help="How many questions to ask during the mock interview.",
        )

        st.divider()
        language_label = st.selectbox(
            "Report language", list(LANGUAGE_OPTIONS.keys()),
            index=list(LANGUAGE_OPTIONS.values()).index(st.session_state.language),
            help="Language used for the generated report's text.",
        )
        st.session_state.language = LANGUAGE_OPTIONS[language_label]

        st.divider()
        strategy_label_to_id = {v["label"]: k for k, v in STRATEGIES.items()}
        selected_label = st.selectbox(
            "Prompt strategy",
            list(strategy_label_to_id.keys()),
            index=list(STRATEGIES.keys()).index(st.session_state.strategy),
            help="Different prompt-engineering techniques for generating the report.",
        )
        st.session_state.strategy = strategy_label_to_id[selected_label]
        st.caption(STRATEGIES[st.session_state.strategy]["description"])

        st.session_state.compare_mode = st.checkbox(
            "Compare prompt strategies",
            value=st.session_state.compare_mode,
            help="Generates multiple reports at once and compares quality, tokens, time, and cost.",
        )
        if st.session_state.compare_mode:
            compare_labels = st.multiselect(
                "Strategies to compare",
                list(strategy_label_to_id.keys()),
                default=[STRATEGIES[sid]["label"] for sid in st.session_state.compare_strategy_ids],
            )
            st.session_state.compare_strategy_ids = [strategy_label_to_id[l] for l in compare_labels]

        if st.session_state.session_total_cost > 0:
            st.divider()
            st.metric("Session cost so far", format_cost(st.session_state.session_total_cost))

        if st.session_state.last_error:
            st.divider()
            with st.expander("🔧 Technical details"):
                st.code(st.session_state.last_error, language=None)

# ---------- Main content (left side) ----------
with main_col:
    with st.container(border=True):
        st.markdown("#### 📌 Job Details")
        col1, col2 = st.columns(2)
        with col1:
            st.session_state.company = st.text_input(
                "Company Name", value=st.session_state.company, placeholder="Google"
            )
        with col2:
            st.session_state.job_title = st.text_input(
                "Job Title", value=st.session_state.job_title, placeholder="AI Engineer"
            )

        url_col, fetch_col = st.columns([4, 1])
        with url_col:
            st.session_state.job_url = st.text_input(
                "Job Posting URL (optional)",
                value=st.session_state.job_url,
                placeholder="https://company.com/careers/ai-engineer",
            )
        with fetch_col:
            st.markdown("<div style='height: 28px'></div>", unsafe_allow_html=True)
            fetch_clicked = st.button("🔗 Fetch", use_container_width=True)

        if fetch_clicked:
            with st.spinner("Fetching job posting..."):
                fetched_text, error = fetch_job_description_from_url(st.session_state.job_url)
            if error:
                st.warning(error)
            else:
                st.session_state.job_description = fetched_text
                st.success("Job description fetched — review it below before generating.")

        mismatch_warning = check_company_mismatch(st.session_state.company, st.session_state.job_url)
        if mismatch_warning:
            st.warning(f"⚠️ {mismatch_warning}")

        st.session_state.job_description = st.text_area(
            "Job Description",
            value=st.session_state.job_description,
            height=200,
            placeholder="Paste the complete job description here, or fetch it from a URL above...",
        )
        st.caption("Required to generate a report.")

    with st.expander("➕ Add your resume for a personalized match (optional)"):
        st.caption(
            "Upload a PDF or Excel file, or paste your resume text. We'll retrieve the parts most relevant "
            "to this job and use them to personalize your resume match."
        )
        uploaded_pdf = st.file_uploader("Upload your Resume (PDF or Excel)", type=["pdf", "xlsx"])
        if uploaded_pdf is not None and uploaded_pdf.name != st.session_state.last_resume_filename:
            with st.spinner("Reading your file..."):
                extracted_text, error = extract_resume_text(uploaded_pdf)
            if error:
                st.warning(error)
            else:
                st.session_state.resume_text = extracted_text
                st.session_state.last_resume_filename = uploaded_pdf.name
                st.success(f"Extracted text from {uploaded_pdf.name}")

        st.caption("Or paste your resume text directly:")
        st.session_state.resume_text = st.text_area(
            "Your Resume / CV",
            value=st.session_state.resume_text,
            height=160,
            placeholder="Paste your resume text here (optional)...",
        )

    btn_col1, btn_col2, btn_col3 = st.columns([2, 1, 1])
    with btn_col1:
        generate_clicked = st.button(
            "🚀 Generate Interview Preparation",
            type="primary",
            use_container_width=True,
            disabled=not st.session_state.job_description.strip(),
        )
    with btn_col2:
        st.button("📄 Example Job Description", on_click=load_example, use_container_width=True)
    with btn_col3:
        st.button("🗑️ Clear Inputs", on_click=clear_inputs, use_container_width=True)

    # ---------- Generate report ----------
    if generate_clicked:
        st.session_state.last_error = None
        sufficient, insufficient_reason = has_sufficient_job_content(
            st.session_state.job_description, st.session_state.job_url
        )
        is_safe, safety_reason = is_safe_input(st.session_state.job_description)

        if not sufficient:
            st.error(f"⚠️ {insufficient_reason}")
        elif not is_safe:
            st.error(f"⚠️ {safety_reason}")
        else:
            with st.spinner("Checking your input..."):
                is_relevant, relevance_reason = is_career_related(st.session_state.job_description)

            if not is_relevant:
                st.error(f"⚠️ {relevance_reason}")
            else:
                try:
                    resume_chunks = []
                    if st.session_state.resume_text.strip():
                        with st.spinner("Reading your resume..."):
                            try:
                                resume_chunks = get_relevant_resume_chunks(
                                    st.session_state.resume_text,
                                    st.session_state.job_description,
                                )
                            except Exception as embed_error:
                                st.session_state.last_error = str(embed_error)
                                resume_chunks = []

                    resume_section = build_resume_section(resume_chunks)
                    lang_directive = language_instruction(st.session_state.language)

                    if st.session_state.compare_mode:
                        results = []
                        strategy_ids = st.session_state.compare_strategy_ids or list(STRATEGIES.keys())
                        for strategy_id in strategy_ids:
                            strategy = STRATEGIES[strategy_id]
                            system_prompt, user_prompt = build_strategy_prompts(
                                strategy_id, st.session_state.company, st.session_state.job_title,
                                st.session_state.job_description, resume_section, lang_directive,
                            )
                            start = time.time()
                            try:
                                with st.spinner(f"Generating with {strategy['label']}..."):
                                    strategy_report, strategy_usage = get_structured_report(
                                        system_prompt=system_prompt, user_prompt=user_prompt,
                                        model=model, temperature=temperature, max_tokens=max_tokens,
                                    )
                                elapsed = time.time() - start
                                strategy_cost = calculate_cost(model, strategy_usage)
                                if strategy_cost:
                                    st.session_state.session_total_cost += strategy_cost["total_cost"]
                                results.append({
                                    "id": strategy_id, "label": strategy["label"],
                                    "description": strategy["description"], "report": strategy_report,
                                    "usage": strategy_usage, "cost": strategy_cost, "elapsed": elapsed,
                                    "quality": score_report_quality(strategy_report), "error": None,
                                })
                            except Exception as strategy_error:
                                elapsed = time.time() - start
                                results.append({
                                    "id": strategy_id, "label": strategy["label"],
                                    "description": strategy["description"], "report": None,
                                    "usage": None, "cost": None, "elapsed": elapsed,
                                    "quality": 0, "error": str(strategy_error),
                                })
                        st.session_state.compare_results = results
                        st.session_state.report = None
                    else:
                        system_prompt, user_prompt = build_strategy_prompts(
                            st.session_state.strategy, st.session_state.company, st.session_state.job_title,
                            st.session_state.job_description, resume_section, lang_directive,
                        )
                        with st.spinner("Preparing your interview report..."):
                            report, usage = get_structured_report(
                                system_prompt=system_prompt, user_prompt=user_prompt,
                                model=model, temperature=temperature, max_tokens=max_tokens,
                            )

                        st.session_state.report = report
                        st.session_state.usage = usage
                        st.session_state.model_used = model
                        st.session_state.compare_results = []

                        cost = calculate_cost(model, usage)
                        st.session_state.cost = cost
                        if cost:
                            st.session_state.session_total_cost += cost["total_cost"]

                        st.session_state.mock_active = False
                        st.session_state.mock_questions = []
                        st.session_state.mock_index = 0
                        st.session_state.mock_transcript = []

                except Exception as e:
                    st.session_state.report = None
                    st.session_state.last_error = str(e)
                    st.error(FRIENDLY_ERROR_MESSAGE)

    # ---------- Comparison results ----------
    if st.session_state.compare_results:
        with st.expander("🔬 Prompt Strategy Comparison", expanded=True):
            st.caption(
                "Quality is a structural-completeness heuristic (are all sections present and "
                "complete?) — not a judgment of writing quality."
            )
            table_rows = []
            for r in st.session_state.compare_results:
                if r["error"]:
                    table_rows.append({
                        "Strategy": r["label"], "Quality": "—", "Prompt tokens": "—",
                        "Completion tokens": "—", "Time (s)": round(r["elapsed"], 1),
                        "Cost": "—", "Status": f"Failed: {r['error'][:60]}",
                    })
                else:
                    cost_str = format_cost(r["cost"]["total_cost"]) if r["cost"] else "N/A"
                    table_rows.append({
                        "Strategy": r["label"], "Quality": f"{r['quality']}%",
                        "Prompt tokens": r["usage"].get("prompt_tokens", "—") if r["usage"] else "—",
                        "Completion tokens": r["usage"].get("completion_tokens", "—") if r["usage"] else "—",
                        "Time (s)": round(r["elapsed"], 1), "Cost": cost_str, "Status": "OK",
                    })
            st.table(table_rows)

            for r in st.session_state.compare_results:
                with st.expander(f"{r['label']} — {r['description']}"):
                    if r["error"]:
                        st.error(f"This strategy failed: {r['error']}")
                        continue
                    st.code(
                        report_to_markdown(r["report"], st.session_state.company, st.session_state.job_title),
                        language="markdown",
                    )
                    if st.button("Use this version →", key=f"use_{r['id']}"):
                        st.session_state.report = r["report"]
                        st.session_state.usage = r["usage"]
                        st.session_state.cost = r["cost"]
                        st.session_state.model_used = model
                        st.session_state.mock_active = False
                        st.session_state.mock_questions = []
                        st.session_state.mock_index = 0
                        st.session_state.mock_transcript = []
                        st.rerun()

    # ---------- Output ----------
    report = st.session_state.report

    if report:
        st.divider()

        usage_parts = [f"**Model:** {st.session_state.model_used}"]
        if st.session_state.cost:
            cost = st.session_state.cost
            total_tokens = cost["prompt_tokens"] + cost["completion_tokens"]
            usage_parts.append(f"**Cost:** {format_cost(cost['total_cost'])}")
            usage_parts.append(f"**Tokens:** {total_tokens:,}")
        st.markdown(f'<div class="usage-strip">{" &nbsp;·&nbsp; ".join(usage_parts)}</div>', unsafe_allow_html=True)

        export_col1, export_col2, _ = st.columns([1, 1, 3])
        markdown_text = report_to_markdown(report, st.session_state.company, st.session_state.job_title)
        with export_col1:
            st.download_button(
                "⬇️ Download as Markdown", data=markdown_text,
                file_name="interview_preparation_report.md", mime="text/markdown",
                use_container_width=True,
            )
        with export_col2:
            try:
                pdf_bytes = report_to_pdf_bytes(report, st.session_state.company, st.session_state.job_title)
                st.download_button(
                    "⬇️ Download as PDF", data=pdf_bytes,
                    file_name="interview_preparation_report.pdf", mime="application/pdf",
                    use_container_width=True,
                )
            except Exception:
                st.download_button(
                    "⬇️ Download as TXT", data=markdown_text,
                    file_name="interview_preparation_report.txt", mime="text/plain",
                    use_container_width=True,
                )

        st.divider()

        company_analysis = report.get("company_analysis", {}) or {}
        job_analysis = report.get("job_analysis", {}) or {}
        resume_match = report.get("resume_match", {}) or {}
        plan = report.get("interview_prep_plan", {}) or {}

        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "🏢 Company Analysis", "🧭 Job Analysis", "🧩 Resume Match",
            "🗺️ Prep Plan", "🎤 Mock Interview",
        ])

        with tab1:
            st.write(company_analysis.get("overview", "No overview available."))
            if company_analysis.get("culture_notes"):
                st.caption(company_analysis.get("culture_notes"))

        with tab2:
            if job_analysis.get("seniority"):
                st.markdown(f"**Seniority:** {job_analysis.get('seniority')}")
            st.write(job_analysis.get("role_summary", ""))

            st.markdown("#### Key Skills")
            skills = job_analysis.get("key_skills", [])
            if skills:
                render_skill_badges(skills)
            else:
                st.write("No skills data returned.")

            st.markdown("#### Topics to Study")
            for t in job_analysis.get("topics_to_study", []):
                stars_filled = "★" * t.get("priority_stars", 0)
                stars_empty = "☆" * (5 - t.get("priority_stars", 0))
                st.markdown(f"**{stars_filled}{stars_empty} {t.get('topic', '')}**")
                st.caption(t.get("reason", ""))

            st.markdown("#### Confidence Score")
            conf = job_analysis.get("confidence_score", {}) or {}
            percentage = conf.get("percentage", 0)
            st.metric("Interview Readiness", f"{percentage}%")
            st.progress(percentage / 100)
            cov_col, imp_col = st.columns(2)
            with cov_col:
                st.markdown("**✅ Already covered**")
                for c in conf.get("covered", []):
                    st.markdown(f"- {c}")
            with imp_col:
                st.markdown("**📈 Should still be improved**")
                for c in conf.get("improve", []):
                    st.markdown(f"- {c}")

        with tab3:
            if not st.session_state.resume_text.strip():
                st.caption("Add your resume above and regenerate for a personalized match.")
            matched = resume_match.get("matched_skills", [])
            gaps = resume_match.get("gaps", [])
            if matched or gaps:
                m_col, g_col = st.columns(2)
                with m_col:
                    st.markdown("**✅ Matched from your resume**")
                    for s in matched:
                        st.markdown(f"- {s}")
                with g_col:
                    st.markdown("**⚠️ Gaps to address**")
                    for g in gaps:
                        st.markdown(f"- {g}")
            st.info(resume_match.get("personalized_note", ""))

        with tab4:
            st.markdown("#### Likely Technical Interview Questions")
            for i, q in enumerate(plan.get("technical_questions", []), 1):
                st.markdown(f"**{i}.** {q}")

            st.markdown("#### Behavioural Questions")
            for i, q in enumerate(plan.get("behavioural_questions", []), 1):
                st.markdown(f"**{i}.** {q}")

            st.markdown("#### Study Plan")
            for day in plan.get("study_plan", []):
                st.markdown(f"**{day.get('day', '')}**")
                for task in day.get("tasks", []):
                    st.markdown(f"- {task}")

            st.markdown("#### Questions to Ask the Interviewer")
            for i, q in enumerate(plan.get("questions_to_ask", []), 1):
                st.markdown(f"**{i}.** {q}")

        with tab5:
            st.caption("Answer one question at a time — you'll get feedback before moving to the next.")

            if not st.session_state.mock_active and not st.session_state.mock_transcript:
                if st.button("🎤 Start Mock Interview"):
                    st.session_state.mock_active = True
                    st.session_state.mock_questions = build_mock_question_list(report)[:mock_question_limit]
                    st.session_state.mock_index = 0
                    st.session_state.mock_transcript = []
                    st.rerun()
            else:
                for entry in st.session_state.mock_transcript:
                    with st.chat_message("assistant"):
                        st.markdown(f"**Q:** {entry['question']}")
                    with st.chat_message("user"):
                        st.markdown(entry["answer"])
                    with st.chat_message("assistant"):
                        st.markdown(entry["feedback"])

                if st.session_state.mock_index < len(st.session_state.mock_questions):
                    current_question = st.session_state.mock_questions[st.session_state.mock_index]
                    with st.chat_message("assistant"):
                        st.markdown(f"**Q{st.session_state.mock_index + 1}:** {current_question}")

                    mock_answer = st.chat_input("Type your answer...")
                    if mock_answer:
                        with st.spinner("Evaluating your answer..."):
                            try:
                                feedback, mock_usage = evaluate_answer(
                                    current_question, mock_answer,
                                    st.session_state.company, st.session_state.job_title,
                                    st.session_state.model_used, temperature,
                                )
                                st.session_state.mock_transcript.append({
                                    "question": current_question, "answer": mock_answer, "feedback": feedback,
                                })
                                st.session_state.mock_index += 1
                                mock_cost = calculate_cost(st.session_state.model_used, mock_usage)
                                if mock_cost:
                                    st.session_state.session_total_cost += mock_cost["total_cost"]
                            except Exception as e:
                                st.session_state.last_error = str(e)
                                st.error(FRIENDLY_ERROR_MESSAGE)
                        st.rerun()
                else:
                    st.success(
                        f"Mock interview complete! You answered "
                        f"{len(st.session_state.mock_transcript)} questions."
                    )
                    if st.button("🔄 Restart Mock Interview"):
                        st.session_state.mock_index = 0
                        st.session_state.mock_transcript = []
                        st.session_state.mock_questions = build_mock_question_list(report)[:mock_question_limit]
                        st.rerun()

    elif not st.session_state.compare_results:
        st.info("Fill in the job details above and click **Generate Interview Preparation** to get started.")
