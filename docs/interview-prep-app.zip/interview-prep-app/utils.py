"""
utils.py
Security guard for user input, report quality scoring, and Markdown/PDF
export.
"""

from fpdf import FPDF

BANNED_PATTERNS = [
    "ignore previous instructions",
    "ignore the above",
    "disregard your instructions",
    "you are now",
    "act as",
    "system prompt",
    "reveal your instructions",
    "jailbreak",
]

MAX_JOB_DESCRIPTION_CHARS = 8000
MIN_JOB_DESCRIPTION_CHARS = 50


def is_safe_input(text: str) -> tuple[bool, str]:
    """Basic prompt-injection / misuse guard. Returns (is_safe, reason_if_not)."""
    if not text or not text.strip():
        return False, "Input cannot be empty."

    if len(text) > MAX_JOB_DESCRIPTION_CHARS:
        return False, f"Job description is too long (max {MAX_JOB_DESCRIPTION_CHARS} characters)."

    lowered = text.lower()
    for pattern in BANNED_PATTERNS:
        if pattern in lowered:
            return False, "Your input contains content that looks like an attempt to override the assistant's instructions."

    return True, ""


def has_sufficient_job_content(job_description: str, job_url: str) -> tuple[bool, str]:
    """
    Blocks obviously-insufficient input (e.g. "bb") when there's also no job
    URL to fall back on, instead of generating a low-quality report from it.
    """
    if len(job_description.strip()) >= MIN_JOB_DESCRIPTION_CHARS:
        return True, ""
    if job_url and job_url.strip():
        return True, ""
    return False, "Please provide a complete job description or a valid job posting URL."


REQUIRED_TOP_KEYS = ["company_analysis", "job_analysis", "resume_match", "interview_prep_plan"]
REQUIRED_LIST_COUNTS = {
    "technical_questions": 10,
    "behavioural_questions": 5,
    "questions_to_ask": 8,
}


def score_report_quality(report: dict) -> int:
    """
    Heuristic structural-completeness score (0-100) for comparing prompt
    strategies at a glance. NOT a judgment of writing quality.
    """
    if not isinstance(report, dict):
        return 0

    score = 0
    total_checks = 0

    for key in REQUIRED_TOP_KEYS:
        total_checks += 1
        if report.get(key):
            score += 1

    plan = report.get("interview_prep_plan", {}) or {}
    for key, expected_count in REQUIRED_LIST_COUNTS.items():
        total_checks += 1
        items = plan.get(key, [])
        if isinstance(items, list) and len(items) >= expected_count:
            score += 1

    total_checks += 1
    role_summary = (report.get("job_analysis", {}) or {}).get("role_summary", "")
    if isinstance(role_summary, str) and len(role_summary) > 60:
        score += 1

    return round((score / total_checks) * 100) if total_checks else 0


def report_to_markdown(report: dict, company: str, job_title: str) -> str:
    """Converts the structured report dict into a clean Markdown document."""
    lines = []
    lines.append("# Interview Preparation Report")
    lines.append(f"**Company:** {company or 'N/A'}  ")
    lines.append(f"**Role:** {job_title or 'N/A'}\n")

    company_analysis = report.get("company_analysis", {}) or {}
    lines.append("## 1. Company Analysis")
    lines.append(company_analysis.get("overview", "") + "\n")
    if company_analysis.get("culture_notes"):
        lines.append(f"_{company_analysis.get('culture_notes')}_\n")

    job_analysis = report.get("job_analysis", {}) or {}
    lines.append("## 2. Job Analysis")
    if job_analysis.get("seniority"):
        lines.append(f"**Seniority:** {job_analysis.get('seniority')}\n")
    lines.append(job_analysis.get("role_summary", "") + "\n")

    lines.append("### Key Skills")
    lines.append("| Skill | Category | Importance | Why it matters |")
    lines.append("|---|---|---|---|")
    for s in job_analysis.get("key_skills", []):
        lines.append(
            f"| {s.get('skill','')} | {s.get('category','')} | {s.get('importance','')} | {s.get('why_it_matters','')} |"
        )
    lines.append("")

    lines.append("### Topics to Study")
    for t in job_analysis.get("topics_to_study", []):
        stars = "★" * t.get("priority_stars", 0) + "☆" * (5 - t.get("priority_stars", 0))
        lines.append(f"- {stars} **{t.get('topic','')}** — {t.get('reason','')}")
    lines.append("")

    conf = job_analysis.get("confidence_score", {}) or {}
    lines.append(f"### Confidence Score: {conf.get('percentage', 0)}%\n")
    lines.append("**Already covered:**")
    for c in conf.get("covered", []):
        lines.append(f"- {c}")
    lines.append("\n**Should still be improved:**")
    for c in conf.get("improve", []):
        lines.append(f"- {c}")
    lines.append("")

    resume_match = report.get("resume_match", {}) or {}
    lines.append("## 3. Resume Match")
    lines.append("**Matched skills:**")
    for s in resume_match.get("matched_skills", []):
        lines.append(f"- {s}")
    lines.append("\n**Gaps:**")
    for g in resume_match.get("gaps", []):
        lines.append(f"- {g}")
    lines.append(f"\n{resume_match.get('personalized_note', '')}\n")

    plan = report.get("interview_prep_plan", {}) or {}
    lines.append("## 4. Interview Preparation Plan")

    lines.append("### Likely Technical Interview Questions")
    for i, q in enumerate(plan.get("technical_questions", []), 1):
        lines.append(f"{i}. {q}")
    lines.append("")

    lines.append("### Behavioural Questions")
    for i, q in enumerate(plan.get("behavioural_questions", []), 1):
        lines.append(f"{i}. {q}")
    lines.append("")

    lines.append("### Study Plan")
    for day in plan.get("study_plan", []):
        lines.append(f"**{day.get('day','')}**")
        for task in day.get("tasks", []):
            lines.append(f"- {task}")
    lines.append("")

    lines.append("### Questions to Ask the Interviewer")
    for i, q in enumerate(plan.get("questions_to_ask", []), 1):
        lines.append(f"{i}. {q}")

    return "\n".join(lines)


def _sanitize_for_pdf(text: str) -> str:
    """Core PDF fonts only support Latin-1. Swap common Unicode punctuation
    for ASCII equivalents, then drop anything else that still won't fit."""
    replacements = {
        "\u2014": "-", "\u2013": "-", "\u2018": "'", "\u2019": "'",
        "\u201c": '"', "\u201d": '"', "\u2026": "...", "\u2022": "-", "\u2192": "->",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.encode("latin-1", errors="ignore").decode("latin-1")


def report_to_pdf_bytes(report: dict, company: str, job_title: str) -> bytes:
    """Converts the structured report into a simple PDF and returns raw bytes."""
    markdown_text = report_to_markdown(report, company, job_title)

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Helvetica", size=11)

    for raw_line in markdown_text.split("\n"):
        line = raw_line.replace("★", "*").replace("☆", "-").replace("**", "")
        line = _sanitize_for_pdf(line)
        stripped = line.strip()

        if stripped and all(ch in "-|: " for ch in stripped):
            continue

        if stripped.startswith("|") and stripped.endswith("|"):
            cells = [c.strip() for c in stripped.strip("|").split("|")]
            line = "  ·  ".join(cells)
            line = _sanitize_for_pdf(line)

        pdf.set_x(pdf.l_margin)

        if line.startswith("# "):
            pdf.set_font("Helvetica", "B", 16)
            pdf.multi_cell(0, 10, line[2:])
            pdf.set_font("Helvetica", size=11)
        elif line.startswith("## "):
            pdf.ln(2)
            pdf.set_font("Helvetica", "B", 13)
            pdf.multi_cell(0, 8, line[3:])
            pdf.set_font("Helvetica", size=11)
        elif line.startswith("### "):
            pdf.ln(1)
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 7, line[4:])
            pdf.set_font("Helvetica", size=11)
        elif line.strip() == "":
            pdf.ln(2)
        else:
            pdf.multi_cell(0, 6, line)

    return bytes(pdf.output(dest="S"))
