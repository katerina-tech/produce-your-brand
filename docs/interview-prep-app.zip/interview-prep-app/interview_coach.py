"""
interview_coach.py
Powers the interactive mock interview: one question at a time, the
candidate answers, the model evaluates that specific answer and gives
feedback, then the next question is asked.
"""

from api_client import call_openrouter

EVALUATOR_SYSTEM_PROMPT_TEMPLATE = (
    "You are conducting a mock interview for the role of {job_title} at {company}. "
    "You will be given one interview question and the candidate's answer to it. "
    "Evaluate the answer honestly but constructively: note what was strong, what was "
    "missing or weak, and give 2-3 concrete suggestions for improvement. Keep your "
    "feedback focused — a short paragraph plus a short bullet list is enough. "
    "Respond in plain conversational text, not JSON."
)


def evaluate_answer(
    question: str,
    answer: str,
    company: str,
    job_title: str,
    model: str,
    temperature: float = 0.5,
) -> tuple[str, dict]:
    """Returns (feedback_text, usage_dict) for a single question/answer pair."""
    system_prompt = EVALUATOR_SYSTEM_PROMPT_TEMPLATE.format(
        job_title=job_title or "this role",
        company=company or "this company",
    )
    user_prompt = f"Interview question: {question}\n\nCandidate's answer: {answer}"

    return call_openrouter(
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        model=model,
        temperature=temperature,
        max_tokens=500,
    )


def build_mock_question_list(report: dict) -> list:
    """Combines technical and behavioural questions into one interview sequence."""
    plan = report.get("interview_prep_plan", {}) or {}
    return plan.get("technical_questions", []) + plan.get("behavioural_questions", [])
