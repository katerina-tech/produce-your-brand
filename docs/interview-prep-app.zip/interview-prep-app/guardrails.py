"""
guardrails.py
Content-scope safeguard: uses a cheap, fast classification call to confirm
the submitted text is actually a job description, career-related content,
or a resume/CV before spending a full report generation on it.
"""

from api_client import call_openrouter

CLASSIFIER_SYSTEM_PROMPT = (
    "You are a strict content classifier for a career and interview preparation tool. "
    "You will be shown a piece of text. Decide whether it is genuinely job, career, "
    "hiring, or resume/CV related content (e.g. a job posting, job description, "
    "role requirements, or someone's resume/CV). "
    "Respond with exactly one word and nothing else: YES or NO."
)


def is_career_related(text: str, model: str = "openai/gpt-5-nano") -> tuple[bool, str]:
    """
    Returns (is_allowed, reason_if_blocked).
    Fails open (allows the request through) if the classifier call itself
    errors out, so a transient API issue never blocks a legitimate user.
    """
    if not text or not text.strip():
        return False, "Please paste a job description first."

    try:
        reply, _ = call_openrouter(
            messages=[
                {"role": "system", "content": CLASSIFIER_SYSTEM_PROMPT},
                {"role": "user", "content": text[:3000]},
            ],
            model=model,
            temperature=0,
            max_tokens=5,
        )
    except Exception:
        return True, ""

    verdict = reply.strip().upper()
    if verdict.startswith("NO"):
        return False, (
            "This tool is designed specifically for job descriptions, career-related "
            "content, and resumes. Please paste content related to a job posting or your CV."
        )

    return True, ""
